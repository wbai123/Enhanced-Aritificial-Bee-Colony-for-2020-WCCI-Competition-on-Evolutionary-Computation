(1) set path to current folder
(2) run mainWCCI_2020.m
(3) If use/modify the codes, please cite "Optimal scheduling of distributed energy resources by modern heuristic optimization technique" 2017 19th International Conference on Intelligent System Application to Power Systems (ISAP)