hfeabcParameters.FoodNumber = 12; %/*The number of food sources equals the half of the colony size*/
hfeabcParameters.limit = 8; %/*A food source which could not be improved through "limit" trials is abandoned by its employed bee*/
hfeabcParameters.maxCycle = 190; %/*The number of cycles for foraging {a stopping criteria}*/
